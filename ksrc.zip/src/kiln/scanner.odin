package kiln

import "core:fmt"
import "core:strconv"


// Tokens =========================================================================================

TokenKind :: enum {
	// Stream markers
	EOF,

	// Literals
	IDENT,
	INT,
	FLOAT,
	STRING,

	// Literal keywords
	TRUE,
	FALSE,
	NIL,

	// Control flow
	IF,
	ELSE,
	FOR,
	FUNCTION,
	RETURN,

	// Binding / construction keywords
	GLOBAL,
	MAP,

	// Binding operators
	DECL,       // :=
	CONST_DECL, // ::
	ASSIGN,     // =

	// Arithmetic operators
	PLUS,
	MINUS,
	STAR,
	SLASH,

	// Comparison / logical operators
	EQUAL,
	NOT,
	NOT_EQUAL,
	LESS,
	LESS_OR_EQUAL,
	GREATER,
	GREATER_OR_EQUAL,

	// Delimiters
	LEFT_PAREN,
	RIGHT_PAREN,
	LEFT_BRACE,
	RIGHT_BRACE,
	LEFT_BRACKET,
	RIGHT_BRACKET,

	// Separators / access
	COMMA,
	DOT,
	COLON,
	SEMICOLON,
}

TokenValue :: union {
	i64,
	f64,
	string,
}

Token :: struct {
	kind:  TokenKind,
	value: TokenValue,

	offset: int, // byte index where this token begins in source
	line:   int, // 1-based source line where this token begins
	column: int, // 1-based source column where this token begins
}

// Cursor =========================================================================================

advance :: proc() -> u8 {
	ch := Compiler.source[Compiler.index]
	Compiler.index += 1

	if ch == '\n' {
		Compiler.line += 1
		Compiler.column = 1
	} else {
		Compiler.column += 1
	}

	return ch
}

begin_token :: proc() {
	Compiler.token_start = Compiler.index
	Compiler.token_line = Compiler.line
	Compiler.token_column = Compiler.column
}

match_next :: proc(expected: u8) -> bool {
	if Compiler.index >= len(Compiler.source) {
		return false
	}

	if Compiler.source[Compiler.index] != expected {
		return false
	}

	advance()
	return true
}


// Emit ===========================================================================================

scanner_error :: proc(message: string) {
	set_error(Compiler.source_name, Compiler.token_line, Compiler.token_column, message)
	Compiler.failed = true
}

emit_token :: proc(kind: TokenKind, value: TokenValue = {}) {
	append(&Compiler.tokens, Token {
		kind   = kind,
		value  = value,
		offset = Compiler.token_start,
		line   = Compiler.token_line,
		column = Compiler.token_column,
	})
}


// Character classes =============================================================================

is_alpha :: proc(ch: u8) -> bool {
	return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')
}

is_digit :: proc(ch: u8) -> bool {
	return ch >= '0' && ch <= '9'
}

is_ident_char :: proc(ch: u8) -> bool {
	return is_alpha(ch) || is_digit(ch) || ch == '_'
}


// Token scans ====================================================================================

scan_ident_or_keyword :: proc() {
	// Identifiers and keywords share the same character rule.
	for Compiler.index < len(Compiler.source) {
		ch := Compiler.source[Compiler.index]
		if !is_ident_char(ch) {
			break
		}
		advance()
	}

	text := Compiler.source[Compiler.token_start:Compiler.index]

	switch text {
	case "true":
		emit_token(.TRUE)
	case "false":
		emit_token(.FALSE)
	case "nil":
		emit_token(.NIL)
	case "if":
		emit_token(.IF)
	case "else":
		emit_token(.ELSE)
	case "for":
		emit_token(.FOR)
	case "function":
		emit_token(.FUNCTION)
	case "return":
		emit_token(.RETURN)
	case "global":
		emit_token(.GLOBAL)
	case "map":
		emit_token(.MAP)
	case:
		emit_token(.IDENT, TokenValue(text))
	}
}

scan_number :: proc() {
	// First pass numbers are decimal integers, hex integers, or decimal floats. No octal or exponent form yet.
	if Compiler.index + 1 < len(Compiler.source) &&
	   Compiler.source[Compiler.index] == '0' &&
	   Compiler.source[Compiler.index + 1] == 'x' {
		advance()
		advance()

		hex_start := Compiler.index
		for Compiler.index < len(Compiler.source) {
			ch := Compiler.source[Compiler.index]
			is_hex_digit := ('0' <= ch && ch <= '9') ||
			                ('a' <= ch && ch <= 'f') ||
			                ('A' <= ch && ch <= 'F')
			if !is_hex_digit {
				break
			}
			advance()
		}

		if Compiler.index == hex_start {
			scanner_error("expected hex digits after 0x")
			return
		}

		if Compiler.index < len(Compiler.source) && is_ident_char(Compiler.source[Compiler.index]) {
			scanner_error("number literal cannot be followed by identifier characters")
			return
		}

		text := Compiler.source[hex_start:Compiler.index]
		value, ok := strconv.parse_i64_of_base(text, 16)
		if !ok {
			scanner_error(fmt.tprintf("failed to parse hex literal %q", text))
			return
		}
		emit_token(.INT, TokenValue(value))
		return
	}

	is_float := false
	if Compiler.source[Compiler.index] == '.' {
		is_float = true
		advance()
	}

	for Compiler.index < len(Compiler.source) {
		ch := Compiler.source[Compiler.index]
		if !is_digit(ch) {
			break
		}
		advance()
	}

	// Treat `123.foo` as INT DOT IDENT, not a malformed float.
	if Compiler.index + 1 < len(Compiler.source) &&
	   Compiler.source[Compiler.index] == '.' &&
	   is_digit(Compiler.source[Compiler.index + 1]) {
		is_float = true
		advance()

		for Compiler.index < len(Compiler.source) {
			ch := Compiler.source[Compiler.index]
			if !is_digit(ch) {
				break
			}
			advance()
		}
	}

	text := Compiler.source[Compiler.token_start:Compiler.index]
	if Compiler.index < len(Compiler.source) && is_ident_char(Compiler.source[Compiler.index]) {
		scanner_error("number literal cannot be followed by identifier characters")
		return
	}

	if is_float {
		value, ok := strconv.parse_f64(text)
		if !ok {
			scanner_error(fmt.tprintf("failed to parse float literal %q", text))
			return
		}
		emit_token(.FLOAT, TokenValue(value))
		return
	}

	value, ok := strconv.parse_i64(text)
	if !ok {
		scanner_error(fmt.tprintf("failed to parse int literal %q", text))
		return
	}
	emit_token(.INT, TokenValue(value))
}

scan_string :: proc() {
	// First pass strings are plain quoted source slices. Escapes are not interpreted yet.
	advance()
	string_start := Compiler.index

	for Compiler.index < len(Compiler.source) && Compiler.source[Compiler.index] != '"' {
		if Compiler.source[Compiler.index] == '\n' {
			scanner_error("unterminated string")
			return
		}
		advance()
	}

	if Compiler.index >= len(Compiler.source) {
		scanner_error("unterminated string")
		return
	}

	text := Compiler.source[string_start:Compiler.index]
	advance()
	emit_token(.STRING, TokenValue(text))
}

skip_line_comment :: proc() {
	// Comments are source trivia for the compiler path, so they emit no token.
	for Compiler.index < len(Compiler.source) && Compiler.source[Compiler.index] != '\n' {
		advance()
	}
}

scan_symbol :: proc() {
	ch := advance()

	switch ch {
	case ':':
		if match_next('=') {
			emit_token(.DECL)
		} else if match_next(':') {
			emit_token(.CONST_DECL)
		} else {
			emit_token(.COLON)
		}

	case '=':
		if match_next('=') {
			emit_token(.EQUAL)
		} else {
			emit_token(.ASSIGN)
		}

	case '!':
		if match_next('=') {
			emit_token(.NOT_EQUAL)
		} else {
			emit_token(.NOT)
		}

	case '<':
		if match_next('=') {
			emit_token(.LESS_OR_EQUAL)
		} else {
			emit_token(.LESS)
		}

	case '>':
		if match_next('=') {
			emit_token(.GREATER_OR_EQUAL)
		} else {
			emit_token(.GREATER)
		}

	case '+':
		emit_token(.PLUS)
	case '-':
		emit_token(.MINUS)
	case '*':
		emit_token(.STAR)
	case '/':
		if match_next('/') {
			skip_line_comment()
		} else {
			emit_token(.SLASH)
		}

	case '(':
		emit_token(.LEFT_PAREN)
	case ')':
		emit_token(.RIGHT_PAREN)
	case '{':
		emit_token(.LEFT_BRACE)
	case '}':
		emit_token(.RIGHT_BRACE)
	case '[':
		emit_token(.LEFT_BRACKET)
	case ']':
		emit_token(.RIGHT_BRACKET)

	case ',':
		emit_token(.COMMA)
	case '.':
		emit_token(.DOT)
	case ';':
		emit_token(.SEMICOLON)

	case:
		scanner_error(fmt.tprintf("unexpected character %q", rune(ch)))
	}
}


// Source scanning =================================================================================

scan_source :: proc(source, source_name: string) -> (tokens: [dynamic]Token, error: ^Error) {
	// Each scan call starts from fresh source/cursor state.
	Compiler.source = source
	Compiler.source_name = source_name
	Compiler.index = 0
	Compiler.line = 1
	Compiler.column = 1
	Compiler.token_start = 0
	Compiler.token_line = 1
	Compiler.token_column = 1
	Compiler.tokens = make([dynamic]Token, 0, len(source) / 4)
	Compiler.token_index = 0
	Compiler.failed = false

	for Compiler.index < len(Compiler.source) && !Compiler.failed {
		ch := Compiler.source[Compiler.index]

		// Whitespace is non-semantic in Kiln source.
		if ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n' {
			advance()
			continue
		}

		begin_token()

		if is_alpha(ch) || ch == '_' {
			scan_ident_or_keyword()
			continue
		}

		if is_digit(ch) {
			scan_number()
			continue
		}

		if ch == '.' && Compiler.index + 1 < len(Compiler.source) && is_digit(Compiler.source[Compiler.index + 1]) {
			scan_number()
			continue
		}

		if ch == '"' {
			scan_string()
			continue
		}

		scan_symbol()
	}

	if Compiler.failed {
		return Compiler.tokens, &Active_State.error
	}

	begin_token()
	emit_token(.EOF)

	return Compiler.tokens, nil
}
