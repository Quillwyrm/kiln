package kiln

import "core:fmt"

// Compiler working state ===================================================================================

Compiler := struct {
	source: string,
	source_name: string,

	// Moving scanner cursor. `index` is a byte index into `source`.
	index:  int,
	line:   int,
	column: int,

	// Start position of the token currently being scanned.
	token_start:  int,
	token_line:   int,
	token_column: int,

	tokens: [dynamic]Token,
	token_index: int,
	failed: bool,
}{}

Active_State: ^State

// Proto-local bindings ===========================================================================
MAX_FRAME_SLOTS :: 256

LocalBinding :: struct {
	name: string,
	frame_slot: int,
}

// Proto state ====================================================================================

ProtoState :: struct {
    name:             string,
    param_count:      int,

    bytecode:         [dynamic]u32,
    const_pool:       [dynamic]Value,
    child_protos:     [dynamic]^Proto,

    frame_slot_count: int,
    local_bindings:      [MAX_FRAME_SLOTS]LocalBinding,
    local_count:      int,
    next_temp_slot:   int,
}

// Token cursor ===================================================================================

current_token :: proc() -> Token {
	return Compiler.tokens[Compiler.token_index]
}

peek_token :: proc() -> Token {
	return Compiler.tokens[Compiler.token_index + 1]
}

at_token :: proc(kind: TokenKind) -> bool {
	return current_token().kind == kind
}

advance_token :: proc() -> Token {
	token := current_token()
	Compiler.token_index += 1
	return token
}

parser_error :: proc(token: Token, message: string) {
	set_error(Compiler.source_name, token.line, token.column, message)
	Compiler.failed = true
}

consume_token :: proc(kind: TokenKind, message: string) -> Token {
	if at_token(kind) {
		return advance_token()
	}

	token := current_token()
	parser_error(token, message)
	return Token{}
}


// Slots and locals ===============================================================================

claim_temp_slot :: proc(proto_state: ^ProtoState) -> int {
	if proto_state.next_temp_slot >= MAX_FRAME_SLOTS {
		parser_error(current_token(), "too many slots in proto")
		return 0
	}

	slot := proto_state.next_temp_slot
	proto_state.next_temp_slot += 1
	return slot
}

declare_local :: proc(proto_state: ^ProtoState, ident_token: Token) -> int {
	name := ident_token.value.(string)

	for local_index := 0; local_index < proto_state.local_count; local_index += 1 {
		if proto_state.local_bindings[local_index].name == name {
			parser_error(ident_token, fmt.tprintf("local already declared: %s", name))
			return 0
		}
	}

	if proto_state.local_count >= MAX_FRAME_SLOTS {
		parser_error(ident_token, "too many local bindings")
		return 0
	}

	slot := proto_state.local_count
	proto_state.local_bindings[proto_state.local_count] = LocalBinding{name = name, frame_slot = slot}
	proto_state.local_count += 1
	proto_state.next_temp_slot = proto_state.local_count
	return slot
}

resolve_local :: proc(proto_state: ^ProtoState, name: string) -> (slot: int, found: bool) {
	for local_index := proto_state.local_count - 1; local_index >= 0; local_index -= 1 {
		if proto_state.local_bindings[local_index].name == name {
			return proto_state.local_bindings[local_index].frame_slot, true
		}
	}

	return 0, false
}


// Expressions ====================================================================================

parse_primary :: proc(proto_state: ^ProtoState, dst: int) {
	token := advance_token()

	#partial switch token.kind {
	case .INT:
		value := token.value.(i64)
		const_index := const_int(proto_state, value)
		emit_load_const(proto_state, dst, const_index)

	case .FLOAT:
		value := token.value.(f64)
		const_index := const_float(proto_state, value)
		emit_load_const(proto_state, dst, const_index)

	case .STRING:
		text := token.value.(string)
		const_index := const_string(proto_state, text)
		emit_load_const(proto_state, dst, const_index)

	case .TRUE:
		emit_load_true(proto_state, dst)

	case .FALSE:
		emit_load_false(proto_state, dst)

	case .NIL:
		emit_load_nil(proto_state, dst)

	case .IDENT:
		name := token.value.(string)
		local_slot, is_local := resolve_local(proto_state, name)
		if is_local {
			emit_move(proto_state, dst, local_slot)
		} else {
			binding_id, found_global := resolve_global(name)
			if !found_global {
				parser_error(token, fmt.tprintf("unknown name: %s", name))
				return
			}
			emit_get_global(proto_state, dst, binding_id)
		}

	case:
		parser_error(token, "expected expression")
	}
}

parse_call :: proc(proto_state: ^ProtoState, callee_slot, requested_results: int) {
	consume_token(.LEFT_PAREN, "expected '(' to start call arguments")
	if Compiler.failed {
		return
	}

	arg_count := 0
	if !at_token(.RIGHT_PAREN) {
		for {
			arg_slot := callee_slot + 1 + arg_count
			if arg_slot >= MAX_FRAME_SLOTS {
				parser_error(current_token(), "too many call arguments or temporary slots")
				return
			}

			parse_expression(proto_state, arg_slot)
			if Compiler.failed {
				return
			}
			arg_count += 1

			if !at_token(.COMMA) {
				break
			}

			advance_token()
			if at_token(.RIGHT_PAREN) {
				break
			}
		}
	}

	consume_token(.RIGHT_PAREN, "expected ')' after call arguments")
	if Compiler.failed {
		return
	}
	emit_call(proto_state, callee_slot, arg_count, requested_results)
}

parse_expression :: proc(proto_state: ^ProtoState, dst: int) {
	parse_primary(proto_state, dst)
	if Compiler.failed {
		return
	}

	if at_token(.LEFT_PAREN) {
		parse_call(proto_state, dst, 1)
	}
}


// Statements =====================================================================================

parse_statement :: proc(proto_state: ^ProtoState) {
	if !at_token(.IDENT) {
		parser_error(current_token(), "expected statement")
		return
	}

	next_kind := peek_token().kind
	if next_kind == .LEFT_PAREN {
		callee_slot := claim_temp_slot(proto_state)
		if Compiler.failed {
			return
		}

		parse_primary(proto_state, callee_slot)
		if Compiler.failed {
			return
		}

		parse_call(proto_state, callee_slot, 0)
		return
	}

	ident_token := advance_token()
	ident_text := ident_token.value.(string)

	if next_kind == .DECL {
		advance_token()

		slot := declare_local(proto_state, ident_token)
		if Compiler.failed {
			return
		}

		parse_expression(proto_state, slot)
		return
	}

	if next_kind == .ASSIGN {
		slot, is_local := resolve_local(proto_state, ident_text)
		if !is_local {
			parser_error(ident_token, "assignment target is not a local")
			return
		}

		advance_token()
		parse_expression(proto_state, slot)
		return
	}

	parser_error(
		ident_token,
		fmt.tprintf("invalid bare expression `%s`; expected declaration, assignment, or call statement", ident_text),
	)
}

parse_top_level_statements :: proc(proto_state: ^ProtoState) {
	for !Compiler.failed && !at_token(.EOF) {
		parse_statement(proto_state)
		if Compiler.failed {
			return
		}
		proto_state.next_temp_slot = proto_state.local_count
	}
}


// Source compilation =============================================================================

compile_source :: proc(state: ^State, source, source_name: string) -> ^Error {
	tokens, scan_error := scan_source(source, source_name)
	defer delete(tokens)
	if scan_error != nil {
		return scan_error
	}

	entry_proto_state := begin_proto("entry", 0)
	parse_top_level_statements(&entry_proto_state)
	if Compiler.failed {
		return &state.error
	}

	return_slot := claim_temp_slot(&entry_proto_state)
	if Compiler.failed {
		return &state.error
	}

	emit_load_nil(&entry_proto_state, return_slot)
	emit_return(&entry_proto_state, return_slot, 1)

	entry_proto := end_proto(&entry_proto_state)
	entry_function := new(ProtoFunctionObject)
	entry_function^ = ProtoFunctionObject{
		header = Object{kind = .PROTO_FUNCTION},
		name   = entry_proto.name,
		impl   = entry_proto,
	}
	state.entry_function = entry_function
	return nil
}
