package kiln

import "core:fmt"

// Parser state ===================================================================================
// working state for token-stream parsing.
// It tracks parse position and parse failure state for one compile operation.

Parser := struct {
    tokens: []Token,
    token_index: int,
    failed: bool,
}{}

// Token cursor ===================================================================================
// helpers over Parser.tokens.
// Parser.token_index points to the current token being parsed.

current_token :: proc() -> Token {
    return Parser.tokens[Parser.token_index]
}

peek_token :: proc() -> Token {
    return Parser.tokens[Parser.token_index + 1]
}

at_token :: proc(kind: TokenKind) -> bool {
    return current_token().kind == kind
}

advance_token :: proc() -> Token {
	token := current_token()
	Parser.token_index += 1
	return token
}


// Parser errors ==================================================================================

// token_text_for_error returns source-shaped text for parser error messages.
token_text_for_error :: proc(token: Token) -> string {
	#partial switch token.kind {
	case .EOF:
		return "end of file"

	case .IDENT:
		return token.value.(string)
	case .INT:
		return fmt.tprint(token.value.(i64))
	case .FLOAT:
		return fmt.tprint(token.value.(f64))
	case .STRING:
		return fmt.tprintf("\"%s\"", token.value.(string))

	case .TRUE:
		return "true"
	case .FALSE:
		return "false"
	case .NIL:
		return "nil"

	case .IF:
		return "if"
	case .ELSE:
		return "else"
	case .FOR:
		return "for"
	case .BREAK:
		return "break"
	case .FUNCTION:
		return "function"
	case .RETURN:
		return "return"

	case .GLOBAL:
		return "global"
	case .MAP:
		return "map"

	case .DECL:
		return ":="
	case .CONST_DECL:
		return "::"
	case .ASSIGN:
		return "="

	case .PLUS:
		return "+"
	case .MINUS:
		return "-"
	case .STAR:
		return "*"
	case .SLASH:
		return "/"

	case .EQUAL:
		return "=="
	case .NOT:
		return "!"
	case .NOT_EQUAL:
		return "!="
	case .LESS:
		return "<"
	case .LESS_OR_EQUAL:
		return "<="
	case .GREATER:
		return ">"
	case .GREATER_OR_EQUAL:
		return ">="

	case .LEFT_PAREN:
		return "("
	case .RIGHT_PAREN:
		return ")"
	case .LEFT_BRACE:
		return "{"
	case .RIGHT_BRACE:
		return "}"
	case .LEFT_BRACKET:
		return "["
	case .RIGHT_BRACKET:
		return "]"

	case .COMMA:
		return ","
	case .DOT:
		return "."
	case .COLON:
		return ":"
	case .SEMICOLON:
		return ";"
	}

	return fmt.tprint(token.kind)
}

// parser_error records a source compile error at a token location.
// This covers grammar errors and codegen limits found while the parser drives bytecode generation.
parser_error :: proc(proto_state: ^ProtoState, token: Token, message: string) {
    set_error(SourceLocation{
        source_name = proto_state.origin.source_name,
        line        = token.line,
        column      = token.column,
    }, message)
    Parser.failed = true
}

// consume_token enforces required grammar tokens.
// On mismatch it records an error and returns zero token value.
consume_token :: proc(proto_state: ^ProtoState, kind: TokenKind, message: string) -> Token {
    if at_token(kind) {
        return advance_token()
    }

    token := current_token()
    parser_error(proto_state, token, message)
    return Token{}
}


// Slots and locals ===============================================================================

// claim_temp_slot reserves one temporary frame slot for expression/call work.
// Temp slots are bounded by MAX_FRAME_SLOTS due to u8 slot encoding.
claim_temp_slot :: proc(proto_state: ^ProtoState) -> int {
    if proto_state.next_temp_slot >= MAX_FRAME_SLOTS {
        parser_error(proto_state, current_token(), "function uses too many values")
        return 0
    }

    slot := proto_state.next_temp_slot
    proto_state.next_temp_slot += 1
    return slot
}

// begin_scope starts one lexical block scope in the current proto.
// It records the local-count mark used when this scope exits.
begin_scope :: proc(proto_state: ^ProtoState) {
	if proto_state.scope_depth >= MAX_FRAME_SLOTS {
		parser_error(proto_state, current_token(), "too many nested scopes")
		return
	}

	proto_state.scope_local_counts[proto_state.scope_depth] = proto_state.local_count
	proto_state.scope_depth += 1
}

// end_scope exits one lexical block scope in the current proto.
// Locals declared in this scope are discarded by restoring the saved local-count mark.
end_scope :: proc(proto_state: ^ProtoState) {
    proto_state.scope_depth -= 1
    proto_state.local_count = proto_state.scope_local_counts[proto_state.scope_depth]
    proto_state.next_temp_slot = proto_state.local_count
}

// declare_local binds one identifier to the next local frame slot.
// Duplicate names are rejected within the current lexical scope only.
declare_local :: proc(proto_state: ^ProtoState, ident_token: Token) -> int {
    ident_name := ident_token.value.(string)

    scope_start := 0
    if proto_state.scope_depth > 0 {
        scope_start = proto_state.scope_local_counts[proto_state.scope_depth - 1]
    }

    for local_index := scope_start; local_index < proto_state.local_count; local_index += 1 {
        if proto_state.local_bindings[local_index].name == ident_name {
            parser_error(
                proto_state,
                ident_token,
                fmt.tprintf("local variable `%s` is already declared in this scope", ident_name),
            )
            return 0
        }
    }

    if proto_state.local_count >= MAX_FRAME_SLOTS {
        parser_error(proto_state, ident_token, "too many local variables in function")
        return 0
    }

    slot := proto_state.local_count
    proto_state.local_bindings[proto_state.local_count] = LocalBinding{name = ident_name, frame_slot = slot}
    proto_state.local_count += 1
    proto_state.next_temp_slot = proto_state.local_count
    return slot
}

// resolve_local finds the nearest local binding by identifier name.
// Reverse scan returns the most recently declared matching local.
resolve_local :: proc(proto_state: ^ProtoState, ident_name: string) -> (slot: int, found: bool) {
    for local_index := proto_state.local_count - 1; local_index >= 0; local_index -= 1 {
        if proto_state.local_bindings[local_index].name == ident_name {
            return proto_state.local_bindings[local_index].frame_slot, true
        }
    }

    return 0, false
}


// Function literals ==============================================================================

// Function bodies consume braces but do not create an extra root scope.
// Parameters and top-level body locals live together in the function's root scope.
// Blocks inside the body still create scopes through normal statement parsing.
parse_function_body :: proc(proto_state: ^ProtoState) {
	consume_token(proto_state, .LEFT_BRACE, "expected '{' to start function body")
    if Parser.failed {
        return
    }

    for !Parser.failed && !at_token(.RIGHT_BRACE) && !at_token(.EOF) {
        parse_statement(proto_state)
        if Parser.failed {
            return
        }
        proto_state.next_temp_slot = proto_state.local_count
    }

    if at_token(.EOF) {
        parser_error(proto_state, current_token(), "expected '}' to close function body")
        return
    }

    consume_token(proto_state, .RIGHT_BRACE, "expected '}' to close function body")
}

// parse_function_literal parses function(params...) { body } as a value expression.
// The compiled child proto is stored on the parent proto and loaded by LOAD_FUNC.
parse_function_literal :: proc(parent_proto_state: ^ProtoState, dst: int, function_name: string, origin_token: Token) {
	consume_token(parent_proto_state, .FUNCTION, "expected 'function'")
    if Parser.failed {
        return
    }

	consume_token(parent_proto_state, .LEFT_PAREN, "expected '(' after function")
	if Parser.failed {
		return
	}

	// Parse parameters first while still compiling the parent.
	// The child proto is not created until the function signature is known.
	param_tokens: [MAX_FRAME_SLOTS]Token
	param_count := 0
	if !at_token(.RIGHT_PAREN) {
        for {
            if param_count >= MAX_FRAME_SLOTS {
                parser_error(parent_proto_state, current_token(), "too many function parameters")
                return
            }

            param_tokens[param_count] = consume_token(parent_proto_state, .IDENT, "expected parameter name")
            if Parser.failed {
                return
            }
            param_count += 1

            if !at_token(.COMMA) {
                break
            }

            advance_token()
            if at_token(.RIGHT_PAREN) {
                break
            }
        }
    }

    consume_token(parent_proto_state, .RIGHT_PAREN, "expected ')' after function parameters")
	if Parser.failed {
		return
	}

	// Build a fresh proto state for the function body.
	// Parent proto state stays alive so the finished child can be appended to it.
	child_origin := SourceLocation{
		source_name = parent_proto_state.origin.source_name,
		line        = origin_token.line,
		column      = origin_token.column,
	}
	child_proto_state := begin_proto(child_origin, function_name, param_count)

	// Parameters are local slots starting at slot 0.
	// The VM call path places arguments directly into those slots.
	for param_index := 0; param_index < param_count; param_index += 1 {
		declare_local(&child_proto_state, param_tokens[param_index])
		if Parser.failed {
			delete_proto_state(&child_proto_state)
            return
        }
    }

    parse_function_body(&child_proto_state)
    if Parser.failed {
		delete_proto_state(&child_proto_state)
		return
	}

	// A function that reaches the closing brace returns nil.
	return_slot := claim_temp_slot(&child_proto_state)
	if Parser.failed {
		delete_proto_state(&child_proto_state)
		return
    }
	emit_load_nil(&child_proto_state, return_slot)
	emit_return(&child_proto_state, return_slot, 1)

	// Store the compiled child proto on the parent, then emit LOAD_FUNC.
	// LOAD_FUNC creates the runtime function object when the parent executes.
    if len(parent_proto_state.child_protos) >= MAX_CHILD_PROTOS {
        delete_proto_state(&child_proto_state)
        parser_error(parent_proto_state, origin_token, "too many functions in function")
        return
    }

	child_proto := end_proto(&child_proto_state)
	child_proto_index := len(parent_proto_state.child_protos)
	append(&parent_proto_state.child_protos, child_proto)
    emit_load_func(parent_proto_state, dst, child_proto_index)
}


// Expressions ====================================================================================

// parse_primary emits one primary expression value into dst.
// IDENT resolves local first, then global binding table by name.
parse_primary :: proc(proto_state: ^ProtoState, dst: int) {
	if at_token(.FUNCTION) {
		parse_function_literal(proto_state, dst, "<function>", current_token())
		return
	}

    token := advance_token()

    #partial switch token.kind {
    case .INT:
        if len(proto_state.const_pool) >= MAX_CONST_POOL_ENTRIES {
            parser_error(proto_state, token, "too many constants in function")
            return
        }

        value := token.value.(i64)
        const_index := const_int(proto_state, value)
        emit_load_const(proto_state, dst, const_index)

    case .FLOAT:
        if len(proto_state.const_pool) >= MAX_CONST_POOL_ENTRIES {
            parser_error(proto_state, token, "too many constants in function")
            return
        }

        value := token.value.(f64)
        const_index := const_float(proto_state, value)
        emit_load_const(proto_state, dst, const_index)

    case .STRING:
        if len(proto_state.const_pool) >= MAX_CONST_POOL_ENTRIES {
            parser_error(proto_state, token, "too many constants in function")
            return
        }

        text := token.value.(string)
        const_index := const_string(proto_state, text)
        emit_load_const(proto_state, dst, const_index)

    case .TRUE:
        emit_load_true(proto_state, dst)

    case .FALSE:
        emit_load_false(proto_state, dst)

    case .NIL:
        emit_load_nil(proto_state, dst)

    case .IDENT:
        ident_name := token.value.(string)
        local_slot, is_local := resolve_local(proto_state, ident_name)
        if is_local {
            emit_move(proto_state, dst, local_slot)
        } else {
            binding_id, found_global := resolve_global(ident_name)
            if !found_global {
                parser_error(proto_state, token, fmt.tprintf("unknown name `%s`", ident_name))
                return
            }
            emit_get_global(proto_state, dst, binding_id)
        }

	case:
		parser_error(proto_state, token, fmt.tprintf("expected expression, got `%s`", token_text_for_error(token)))
	}
}

// parse_unary parses prefix unary operators and primary expressions.
// Prefix NOT lowers by evaluating the operand first, then emitting NOT into dst.
parse_unary :: proc(proto_state: ^ProtoState, dst: int) {
    if at_token(.NOT) {
        advance_token()

        operand_slot := claim_temp_slot(proto_state)
        if Parser.failed {
            return
        }

        parse_unary(proto_state, operand_slot)
        if Parser.failed {
            return
        }

        emit_not(proto_state, dst, operand_slot)
        return
    }

    parse_primary(proto_state, dst)
    if Parser.failed {
        return
    }

    if at_token(.LEFT_PAREN) {
        parse_call(proto_state, dst, 1)
    }
}

// parse_call lowers callee(args...) using contiguous call slots:
// callee_slot, arg0, arg1, ...
// requested_results controls VM CALL result shaping (0 for statements, 1 for expressions).
parse_call :: proc(proto_state: ^ProtoState, callee_slot, requested_results: int) {
    consume_token(proto_state, .LEFT_PAREN, "expected '(' to start call arguments")
    if Parser.failed {
        return
    }

    arg_count := 0
    if !at_token(.RIGHT_PAREN) {
        for {
            arg_slot := callee_slot + 1 + arg_count
            if arg_slot >= MAX_FRAME_SLOTS {
                parser_error(proto_state, current_token(), "call uses too many values")
                return
            }

            parse_expression(proto_state, arg_slot)
            if Parser.failed {
                return
            }
            arg_count += 1

            if !at_token(.COMMA) {
                break
            }

            advance_token()
            if at_token(.RIGHT_PAREN) {
                break
            }
        }
    }

    consume_token(proto_state, .RIGHT_PAREN, "expected ')' after call arguments")
    if Parser.failed {
        return
    }
    emit_call(proto_state, callee_slot, arg_count, requested_results)
}

// parse_expression currently supports unary expressions and call suffix on primaries.
// Operator precedence parsing is not in this stage yet.
parse_expression :: proc(proto_state: ^ProtoState, dst: int) {
    parse_unary(proto_state, dst)
}


// Statements =====================================================================================

// parse_block parses one braced statement block.
// Blocks create a new lexical local scope.
parse_block :: proc(proto_state: ^ProtoState) {
    consume_token(proto_state, .LEFT_BRACE, "expected '{' to start block")
    if Parser.failed {
        return
	}

	begin_scope(proto_state)
	if Parser.failed {
		return
	}

	for !Parser.failed && !at_token(.RIGHT_BRACE) && !at_token(.EOF) {
        parse_statement(proto_state)
        if Parser.failed {
            return
        }
        proto_state.next_temp_slot = proto_state.local_count
    }

    if at_token(.EOF) {
        parser_error(proto_state, current_token(), "expected '}' to close block")
        return
    }

    consume_token(proto_state, .RIGHT_BRACE, "expected '}' to close block")
    if Parser.failed {
        return
    }

    end_scope(proto_state)
}

// parse_if_statement parses:
// if <expression> { <statements> } [else { <statements> }]
parse_if_statement :: proc(proto_state: ^ProtoState) {
    consume_token(proto_state, .IF, "expected 'if'")
    if Parser.failed {
        return
    }

    condition_slot := claim_temp_slot(proto_state)
    if Parser.failed {
        return
    }

    parse_expression(proto_state, condition_slot)
    if Parser.failed {
        return
    }

    false_jump := emit_jump_false(proto_state, condition_slot)
    parse_block(proto_state)
    if Parser.failed {
        return
    }

    if at_token(.ELSE) {
        advance_token()

        end_jump := emit_jump(proto_state)
        patch_jump(proto_state, false_jump)
        if Parser.failed {
            return
        }

        if at_token(.IF) {
            parse_if_statement(proto_state)
        } else {
            parse_block(proto_state)
        }
        if Parser.failed {
            return
        }

        patch_jump(proto_state, end_jump)
        if Parser.failed {
            return
        }
        return
    }

    patch_jump(proto_state, false_jump)
    if Parser.failed {
        return
    }
}

// parse_for_statement parses:
// for <expression> { <statements> }
// for { <statements> }
// Condition form evaluates each iteration.
// Braced form is infinite-loop sugar with no condition-exit jump.
parse_for_statement :: proc(proto_state: ^ProtoState) {
    consume_token(proto_state, .FOR, "expected 'for'")
    if Parser.failed {
        return
    }

    if proto_state.loop_depth >= MAX_LOOP_DEPTH {
        parser_error(proto_state, current_token(), "too many nested loops")
        return
    }
    proto_state.loop_break_fixup_base[proto_state.loop_depth] = proto_state.break_fixup_count
    proto_state.loop_depth += 1

    loop_start := next_inst_index(proto_state)
    has_exit_jump := false
    exit_jump := 0

    // `for { ... }` has no condition expression.
    // It loops until `break`, `return`, or runtime termination.
    if !at_token(.LEFT_BRACE) {
        condition_slot := claim_temp_slot(proto_state)
        if Parser.failed {
            return
        }

        parse_expression(proto_state, condition_slot)
        if Parser.failed {
            return
        }

        exit_jump = emit_jump_false(proto_state, condition_slot)
        has_exit_jump = true
    }

    parse_block(proto_state)
    if Parser.failed {
        return
    }

    emit_jump(proto_state, loop_start)
    if Parser.failed {
        return
    }

    if has_exit_jump {
        patch_jump(proto_state, exit_jump)
        if Parser.failed {
            return
        }
    }

    proto_state.loop_depth -= 1
    break_fixup_base := proto_state.loop_break_fixup_base[proto_state.loop_depth]
    for fixup_index := break_fixup_base; fixup_index < proto_state.break_fixup_count; fixup_index += 1 {
        patch_jump(proto_state, proto_state.break_fixups[fixup_index])
        if Parser.failed {
            return
        }
    }
    proto_state.break_fixup_count = break_fixup_base
}

// parse_break_statement parses:
// break
// break is only valid inside loop bodies.
parse_break_statement :: proc(proto_state: ^ProtoState) {
    break_token := consume_token(proto_state, .BREAK, "expected 'break'")
    if Parser.failed {
        return
    }

    if proto_state.loop_depth == 0 {
        parser_error(proto_state, break_token, "break is only valid inside loops")
        return
    }

    if proto_state.break_fixup_count >= MAX_BREAK_FIXUPS {
        parser_error(proto_state, break_token, "function has too many break statements")
        return
    }

    break_jump := emit_jump(proto_state)
    proto_state.break_fixups[proto_state.break_fixup_count] = break_jump
    proto_state.break_fixup_count += 1
}

// parse_return_statement parses:
// - return
// - return expr
// - return expr, expr, ...
// Each return expression is lowered as a single-result expression.
parse_return_statement :: proc(proto_state: ^ProtoState) {
    consume_token(proto_state, .RETURN, "expected 'return'")
    if Parser.failed {
        return
    }

    if at_token(.EOF) || at_token(.RIGHT_BRACE) {
        emit_return(proto_state, 0, 0)
        return
    }

    first_result_slot := claim_temp_slot(proto_state)
    if Parser.failed {
        return
    }

    parse_expression(proto_state, first_result_slot)
    if Parser.failed {
        return
    }

    result_count := 1
    for at_token(.COMMA) {
        advance_token()

        result_slot := first_result_slot + result_count
        if result_slot >= MAX_FRAME_SLOTS {
            parser_error(proto_state, current_token(), "return has too many values")
            return
        }

        parse_expression(proto_state, result_slot)
        if Parser.failed {
            return
        }
        result_count += 1
    }

    emit_return(proto_state, first_result_slot, result_count)
}

// parse_statement supports:
// - if expression block [else block]
// - for expression block
// - break
// - return [expr [, expr ...]]
// - ident := expression
// - ident = expression (local-only assignment)
// - call statement
parse_statement :: proc(proto_state: ^ProtoState) {
    if at_token(.RETURN) {
        parse_return_statement(proto_state)
        return
    }

    if at_token(.IF) {
        parse_if_statement(proto_state)
        return
    }

    if at_token(.FOR) {
        parse_for_statement(proto_state)
        return
    }

    if at_token(.BREAK) {
        parse_break_statement(proto_state)
        return
    }

	if !at_token(.IDENT) {
		token := current_token()
		parser_error(proto_state, token, fmt.tprintf("expected statement, got `%s`", token_text_for_error(token)))
		return
	}

    next_kind := peek_token().kind
    if next_kind == .LEFT_PAREN {
        callee_slot := claim_temp_slot(proto_state)
        if Parser.failed {
            return
        }

        parse_primary(proto_state, callee_slot)
        if Parser.failed {
            return
        }

        parse_call(proto_state, callee_slot, 0)
        return
    }

    ident_token := advance_token()
    ident_text := ident_token.value.(string)

    if next_kind == .DECL {
        advance_token()

        slot := declare_local(proto_state, ident_token)
        if Parser.failed {
			return
		}

		// Declaration gives the function proto a useful name and origin.
		if at_token(.FUNCTION) {
			parse_function_literal(proto_state, slot, ident_text, ident_token)
			return
		}

        parse_expression(proto_state, slot)
        return
    }

    if next_kind == .ASSIGN {
        slot, is_local := resolve_local(proto_state, ident_text)
        if !is_local {
            parser_error(proto_state, ident_token, fmt.tprintf("assignment target `%s` is not a local variable", ident_text))
            return
        }

        advance_token()
        parse_expression(proto_state, slot)
        return
    }

    parser_error(
        proto_state,
        ident_token,
        fmt.tprintf("bare expression `%s` is not a statement; expected declaration, assignment, or call", ident_text),
    )
}

// parse_top_level_statements parses until EOF or first parse failure.
// After each statement, next_temp_slot resets to local_count so temporary slots are reused.
parse_top_level_statements :: proc(proto_state: ^ProtoState) {
    for !Parser.failed && !at_token(.EOF) {
        parse_statement(proto_state)
        if Parser.failed {
            return
        }
        proto_state.next_temp_slot = proto_state.local_count
    }
}


// Source compilation =============================================================================

// compile_source scans source, parses top-level forms, and builds entry proto.
// On success it installs Active_State.entry_function for VM execution.
compile_source :: proc(source, source_name: string) -> ^Error {
    tokens, scan_error := scan_source(source, source_name)
    defer delete(tokens)
    if scan_error != nil {
        return scan_error
    }

    Parser.tokens = tokens[:]
    Parser.token_index = 0
    Parser.failed = false

	entry_origin := SourceLocation{
		source_name = source_name,
		line        = 1,
		column      = 1,
	}
	entry_proto_state := begin_proto(entry_origin, "entry", 0)
    parse_top_level_statements(&entry_proto_state)
    if Parser.failed {
		delete_proto_state(&entry_proto_state)
        return &Active_State.error
    }

    // Source fallthrough is defined as implicit `return nil`.
    // This keeps entry completion on the same RETURN path as explicit source returns.
    return_slot := claim_temp_slot(&entry_proto_state)
    if Parser.failed {
		delete_proto_state(&entry_proto_state)
        return &Active_State.error
    }
    emit_load_nil(&entry_proto_state, return_slot)
    emit_return(&entry_proto_state, return_slot, 1)

    entry_proto := end_proto(&entry_proto_state)
    entry_function := new(ProtoFunctionObject)
    entry_function^ = ProtoFunctionObject{
        header = Object{kind = .PROTO_FUNCTION},
        name   = entry_proto.name,
        impl   = entry_proto,
    }
    Active_State.entry_function = entry_function
    return nil
}
